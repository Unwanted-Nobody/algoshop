import { Cpu, TrendingUp, Zap } from 'lucide-react'

const HeroSection = () => {
  return (
    <div className="relative w-full rounded-elite overflow-hidden bg-[#111112] border border-[#2a2a2c] p-8 md:p-12">
      {/* Background Elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-elite-violet/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-elite-gold/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/3"></div>
      
      <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
        
        {/* Left Content */}
        <div className="max-w-xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-elite-gold/10 border border-elite-gold/30 text-elite-gold text-xs font-semibold tracking-widest uppercase mb-6">
            <Zap size={14} className="animate-pulse" />
            AI Inference Active
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold mb-4 tracking-tight leading-tight">
            Discover <span className="text-transparent bg-clip-text bg-gradient-to-r from-elite-gold to-[#f9d976]">Elite Assets</span> with Precision
          </h2>
          
          <p className="text-gray-400 text-lg mb-8 leading-relaxed max-w-md">
            Your personal AI conciege. Analyzing global markets to curate high-end watches, rare tech, and luxury collectibles.
          </p>
          
          <div className="flex gap-4">
            <button className="elite-button bg-elite-gold text-elite-black hover:bg-white border-transparent">
              Start Auto-Trade
            </button>
            <button className="text-sm font-medium uppercase tracking-widest text-gray-400 hover:text-elite-text transition-colors flex items-center gap-2 border-b border-transparent hover:border-elite-text pb-1">
              View Insights <TrendingUp size={16} />
            </button>
          </div>
        </div>
        
        {/* Right Status Panel (AI Loader) */}
        <div className="w-full md:w-auto relative group">
          <div className="absolute inset-0 bg-elite-gold/5 blur-2xl rounded-full block group-hover:bg-elite-gold/10 transition-all duration-700"></div>
          
          <div className="relative manga-glass rounded-elite p-6 flex flex-col items-center justify-center min-w-[240px] border border-[#333] group-hover:border-elite-gold/50 transition-all duration-500">
            {/* Minimalist Spinner */}
            <div className="relative w-24 h-24 mb-6">
              <div className="absolute inset-0 rounded-full border-t-2 border-r-2 border-elite-gold animate-spin-slow shadow-gold-glow"></div>
              <div className="absolute inset-3 rounded-full border-b-2 border-l-2 border-elite-violet animate-[spin_4s_linear_infinite_reverse] shadow-violet-glow"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <Cpu size={24} className="text-elite-gold opacity-80" />
              </div>
            </div>
            
            <h3 className="text-sm font-semibold tracking-widest uppercase text-elite-text mb-1">Algo Engine</h3>
            <p className="text-xs text-gray-500 font-mono mb-4">Scanning 14,204 DBs</p>
            
            <div className="w-full bg-[#111112] rounded-full h-1.5 overflow-hidden">
              <div className="bg-gradient-to-r from-elite-violet to-elite-gold h-full w-2/3 relative">
                <div className="absolute inset-0 w-full h-full bg-white/20 animate-[pulse_2s_ease-in-out_infinite]"></div>
              </div>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  )
}

export default HeroSection
