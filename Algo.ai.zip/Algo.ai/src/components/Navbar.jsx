import { Search, Bell, Settings, Zap } from 'lucide-react'

const Navbar = ({ balance, userName }) => {
  return (
    <header className="h-20 bg-[#0b0b0c]/90 backdrop-blur-md border-b border-[#1a1a1c] flex items-center justify-between px-6 z-10 sticky top-0">
      
      {/* Search Bar with focused gold glow */}
      <div className="flex-1 max-w-xl group relative">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500 group-focus-within:text-elite-gold transition-colors">
            <Search size={18} />
          </div>
          <input 
            type="text" 
            placeholder="Search high-end watches, tech, and collectibles..." 
            className="w-full bg-[#111112] border border-[#333] rounded-elite pl-10 pr-4 py-2.5 text-sm text-elite-text focus:outline-none focus:border-elite-gold focus:shadow-gold-glow transition-all duration-500"
          />
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
            <div className="hidden sm:flex border border-[#333] rounded px-1.5 py-0.5 text-[10px] text-gray-500 font-mono">
              ⌘K
            </div>
          </div>
        </div>

        {/* Algo Suggest Search Dropdown */}
        <div className="absolute top-12 left-0 w-full bg-[#111112] border border-elite-gold/30 rounded-elite shadow-gold-glow z-50 p-2 hidden group-focus-within:block animate-fade-in">
          <div className="text-[10px] text-elite-gold font-bold p-2 uppercase tracking-[0.2em] border-b border-[#333] flex items-center gap-2">
            <Zap size={12} className="text-elite-violet" /> Algo Suggestions
          </div>
          <div className="p-3 hover:bg-[#1a1a1c] cursor-pointer text-sm text-white transition-colors flex justify-between items-center group/item rounded mt-1">
            <span>Capsule Corp Dragon Radar V2 <span className="text-xs text-orange-500 ml-2 border border-orange-500/30 px-1 rounded bg-orange-500/10">DBZ</span></span>
            <span className="text-elite-gold opacity-0 group-hover/item:opacity-100 text-xs">Analyze</span>
          </div>
           <div className="p-3 hover:bg-[#1a1a1c] cursor-pointer text-sm text-white transition-colors flex justify-between items-center group/item rounded">
            <span>Militech Sandevistan Mk.4 <span className="text-xs text-cyan-400 ml-2 border border-cyan-400/30 px-1 rounded bg-cyan-400/10">Cyberpunk</span></span>
            <span className="text-elite-gold opacity-0 group-hover/item:opacity-100 text-xs">Analyze</span>
          </div>
        </div>
      </div>

      {/* Right Side */}
      <div className="flex items-center gap-6 ml-4">
        
        {/* Country Option */}
        <div className="hidden md:flex items-center gap-1 bg-[#1a1a1c] border border-[#333] px-3 py-1.5 rounded-elite">
          <select className="bg-transparent text-xs text-gray-300 focus:outline-none cursor-pointer uppercase font-semibold tracking-wider">
            <option value="US">🇺🇸 USD</option>
            <option value="JP">🇯🇵 JPY</option>
            <option value="UK">🇬🇧 GBP</option>
            <option value="IN">🇮🇳 INR</option>
          </select>
        </div>

        {/* Balance Badge */}
        <div className="hidden md:flex items-center gap-2 bg-[#1a1a1c] border border-[#333] px-4 py-1.5 rounded-elite">
          <span className="text-xs text-gray-400 uppercase tracking-wider">Wallet</span>
          <span className="text-sm font-medium text-elite-gold">${balance.toLocaleString('en-US', {minimumFractionDigits: 2})}</span>
        </div>

        {/* Icons */}
        <div className="flex items-center gap-3">
          <button className="relative w-10 h-10 rounded-elite bg-[#111112] border border-[#333] flex items-center justify-center text-gray-400 hover:text-elite-gold hover:border-elite-gold transition-all">
            <Bell size={18} />
            <span className="absolute top-2 right-2 w-2 h-2 bg-elite-violet rounded-full shadow-violet-glow"></span>
          </button>
          <button className="w-10 h-10 rounded-elite bg-[#111112] border border-[#333] flex items-center justify-center text-gray-400 hover:text-elite-gold hover:border-elite-gold transition-all">
            <Settings size={18} />
          </button>
        </div>

      </div>
    </header>
  )
}

export default Navbar
