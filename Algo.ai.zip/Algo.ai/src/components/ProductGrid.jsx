import { Award, ShoppingCart, Heart } from 'lucide-react'

const products = [
  {
    id: 1,
    name: "Capsule Corp Dragon Radar V2",
    brand: "BULMA TECH",
    price: 34500.00,
    discount: "-12%",
    image: "https://images.unsplash.com/photo-1542204165-65bf26472b9b?auto=format&fit=crop&w=600&q=80",
    ribbon: "BEST DEAL",
    tag: "DBZ-GRADE"
  },
  {
    id: 2,
    name: "Militech 'Sandevistan' Mk.4",
    brand: "ARASAKA",
    price: 4200.00,
    discount: null,
    image: "https://images.unsplash.com/photo-1614729939124-03290b5609ce?auto=format&fit=crop&w=600&q=80",
    ribbon: null,
    tag: "CYBER-GEAR"
  },
  {
    id: 3,
    name: "Eva-01 Biomechanical Core",
    brand: "NERV",
    price: 1850.00,
    discount: "-5%",
    image: "https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&w=600&q=80",
    ribbon: "RARE",
    tag: "S-GRADE"
  },
  {
    id: 4,
    name: "Edgerunner Neural Link",
    brand: "NIGHT CITY",
    price: 125000.00,
    discount: null,
    image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=600&q=80",
    ribbon: null,
    tag: "SS-GRADE"
  }
]

const ProductGrid = ({ title, limit }) => {
  const displayProducts = limit ? products.slice(0, limit) : products;

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold tracking-wide uppercase">{title}</h3>
        <button className="text-xs font-semibold text-elite-gold hover:text-white uppercase tracking-widest transition-colors">
          View All
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 2xl:grid-cols-3 gap-6">
        {displayProducts.map((product) => (
          <div key={product.id} className="elite-card group cursor-pointer h-full flex flex-col relative">
            
            {product.ribbon && (
              <div className="absolute top-4 -left-2 z-10">
                <div className="bg-elite-gold text-black text-[10px] font-bold px-3 py-1 uppercase tracking-widest shadow-gold-glow">
                  {product.ribbon}
                </div>
                <div className="w-0 h-0 border-t-[8px] border-t-yellow-600 border-l-[8px] border-l-transparent absolute -bottom-[8px] left-0"></div>
              </div>
            )}
            
            <button className="absolute top-4 right-4 z-10 w-8 h-8 rounded-full bg-black/50 backdrop-blur border border-white/10 flex items-center justify-center text-white/50 hover:text-red-500 hover:border-red-500/50 transition-all opacity-0 group-hover:opacity-100">
              <Heart size={14} />
            </button>

            <div className="h-48 overflow-hidden relative bg-[#0b0b0c]">
              <div className="absolute inset-0 bg-gradient-to-t from-[#111112] to-transparent z-0"></div>
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-700 mix-blend-luminosity hover:mix-blend-normal"
              />
            </div>
            
            <div className="p-5 flex-1 flex flex-col">
              <div className="flex justify-between items-start mb-2">
                <span className="text-[10px] text-gray-500 tracking-[0.2em] uppercase font-semibold">{product.brand}</span>
                <span className="text-[10px] text-elite-violet border border-elite-violet/30 px-1.5 rounded bg-elite-violet/5 font-mono shadow-violet-glow group-hover:bg-elite-violet/20">{product.tag}</span>
              </div>
              
              <h4 className="text-sm font-semibold mb-4 text-gray-200 group-hover:text-white transition-colors line-clamp-2">
                {product.name}
              </h4>
              
              <div className="mt-auto flex items-end justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-bold text-elite-gold font-mono">
                      ${product.price.toLocaleString('en-US', {minimumFractionDigits: 2})}
                    </span>
                    {product.discount && (
                      <span className="text-xs text-green-400 bg-green-400/10 px-1.5 py-0.5 rounded border border-green-400/20 font-mono">
                        {product.discount}
                      </span>
                    )}
                  </div>
                </div>
                
                <button className="px-3 py-1.5 rounded-elite bg-elite-gold border border-elite-gold flex items-center justify-center text-black font-semibold text-xs transition-all duration-300 shadow-gold-glow hover:bg-white flex-1 ml-4 gap-2">
                  <ShoppingCart size={14} /> Buy w/ Wallet
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default ProductGrid
