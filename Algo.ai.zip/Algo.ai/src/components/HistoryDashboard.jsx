import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { CheckCircle2, XCircle, Clock } from 'lucide-react'

const data = [
  { name: 'Jan', value: 24000 },
  { name: 'Feb', value: 41398 },
  { name: 'Mar', value: 38000 },
  { name: 'Apr', value: 59080 },
  { name: 'May', value: 48000 },
  { name: 'Jun', value: 88000 },
];

const transactions = [
  { id: 'TRX-9482', item: "Patek Philippe Aquanaut", date: "Today, 14:24", amount: "$45,000.00", status: 'completed' },
  { id: 'TRX-9481', item: "Sony A7RV Initial Deposit", date: "Yesterday", amount: "$900.00", status: 'pending' },
  { id: 'TRX-9480', item: "Hako-Tech Cyberdeck", date: "Apr 04", amount: "$4,200.00", status: 'completed' },
  { id: 'TRX-9479', item: "Vintage Casio G-Shock", date: "Apr 01", amount: "$450.00", status: 'failed' },
]

const HistoryDashboard = () => {
  return (
    <div className="space-y-6 mt-6">
      <div className="manga-glass rounded-elite border border-[#2a2a2c] p-6 lg:p-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-xl font-bold tracking-wide uppercase">Acquisition Velocity</h2>
            <p className="text-xs text-gray-500 tracking-widest uppercase mt-1">6-Month Trajectory</p>
          </div>
          <div className="flex gap-2">
            <button className="px-3 py-1 rounded bg-[#111112] border border-[#333] text-xs font-mono text-gray-400 hover:text-white transition-colors">1M</button>
            <button className="px-3 py-1 rounded bg-elite-gray border border-elite-gold text-elite-gold text-xs font-mono shadow-gold-glow">6M</button>
            <button className="px-3 py-1 rounded bg-[#111112] border border-[#333] text-xs font-mono text-gray-400 hover:text-white transition-colors">YTD</button>
          </div>
        </div>
        
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1a1a1c" vertical={false} />
              <XAxis dataKey="name" stroke="#555" tick={{fill: '#555', fontSize: 12}} tickLine={false} axisLine={false} />
              <YAxis stroke="#555" tick={{fill: '#555', fontSize: 12, fontFamily: 'monospace'}} tickLine={false} axisLine={false} tickFormatter={(val) => `$${val/1000}k`} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0b0b0c', borderColor: '#d4af37', borderRadius: '4px', boxShadow: '0 0 15px rgba(212, 175, 55, 0.1)' }}
                itemStyle={{ color: '#d4af37', fontFamily: 'monospace' }}
              />
              <Line type="monotone" dataKey="value" stroke="#d4af37" strokeWidth={3} dot={{r: 4, fill: '#0b0b0c', stroke: '#d4af37', strokeWidth: 2}} activeDot={{r: 6, fill: '#d4af37', stroke: '#0b0b0c', strokeWidth: 2}} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="manga-glass rounded-elite border border-[#2a2a2c] overflow-hidden">
        <div className="p-6 border-b border-[#1a1a1c]">
          <h3 className="text-sm font-bold tracking-widest uppercase">Transaction Ledger</h3>
        </div>
        <div className="divide-y divide-[#1a1a1c]">
          {transactions.map((tx) => (
            <div key={tx.id} className="p-4 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-[#111112] transition-colors">
              <div className="flex flex-col">
                <span className="text-sm font-semibold text-gray-200">{tx.item}</span>
                <div className="flex items-center gap-3 mt-1">
                  <span className="text-[10px] text-gray-500 font-mono">{tx.id}</span>
                  <span className="text-[10px] text-gray-500 uppercase tracking-widest bg-[#111112] px-2 py-0.5 rounded">{tx.date}</span>
                </div>
              </div>
              <div className="flex items-center justify-between sm:justify-end sm:w-1/3 gap-6">
                <span className="font-mono font-medium">{tx.amount}</span>
                <div className="w-24 flex justify-end">
                  {tx.status === 'completed' && <div className="flex items-center gap-1.5 text-xs text-green-400 font-semibold uppercase tracking-wider"><CheckCircle2 size={14} /> Done</div>}
                  {tx.status === 'pending' && <div className="flex items-center gap-1.5 text-xs text-yellow-500 font-semibold uppercase tracking-wider"><Clock size={14} /> Pend</div>}
                  {tx.status === 'failed' && <div className="flex items-center gap-1.5 text-xs text-red-500 font-semibold uppercase tracking-wider"><XCircle size={14} /> Fail</div>}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default HistoryDashboard
