import { ArrowUpRight, ArrowDownRight, Activity, Cpu } from 'lucide-react'

const PortfolioPanel = ({ balance, expanded = false }) => {
  const stats = [
    { label: "Predictive Match Rate", value: "99.8%", trend: "+1.2%", isPositive: true },
    { label: "Market Sentiment", value: "BULLISH", trend: "High", isPositive: true },
    { label: "Global Availability", value: "14 Units", trend: "Dropping", isPositive: false },
  ]

  return (
    <div className={`manga-glass rounded-elite border border-[#2a2a2c] p-6 h-full flex flex-col ${expanded ? 'max-w-4xl mx-auto mt-6' : ''}`}>
      <div className="flex items-center justify-between mb-8">
        <h3 className="text-sm font-bold tracking-widest uppercase text-gray-400">Algo Suggestions</h3>
        <button className="text-elite-violet hover:text-white transition-colors bg-elite-violet/10 p-1.5 rounded border border-elite-violet/20">
          <Cpu size={16} />
        </button>
      </div>

      <div className="mb-8">
        <div className="text-2xl font-bold tracking-tight mb-2 font-mono text-elite-gold">
          TARGET ACQUIRED
        </div>
        <div className="flex items-center gap-2 text-sm">
          <span className="text-green-400 flex items-center bg-green-400/10 px-1.5 py-0.5 rounded border border-green-400/20 font-mono">
            <ArrowUpRight size={14} className="mr-1" /> Super Rare
          </span>
          <span className="text-gray-500 uppercase tracking-wider text-[10px]">CyberPunk / DBZ Collection</span>
        </div>
      </div>

      <div className="space-y-4 flex-1">
        {stats.map((stat, i) => (
          <div key={i} className="bg-[#111112] border border-[#333] rounded p-4 group hover:border-[#444] transition-colors">
            <div className="text-[10px] text-gray-500 uppercase tracking-widest mb-1">{stat.label}</div>
            <div className="flex items-end justify-between">
              <div className="text-lg font-semibold font-mono text-gray-200 group-hover:text-white transition-colors">{stat.value}</div>
              <div className={`flex items-center text-xs font-mono font-medium ${stat.isPositive ? 'text-green-400' : 'text-red-400'}`}>
                {stat.isPositive ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                {stat.trend}
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {!expanded && (
        <button className="mt-6 w-full text-xs font-semibold text-elite-violet hover:text-white uppercase tracking-widest py-3 border-t border-[#2a2a2c] transition-colors flex justify-center items-center gap-2">
          Execute Algorithmic Buy <Cpu size={14} />
        </button>
      )}
    </div>
  )
}

export default PortfolioPanel
