import { useState } from 'react'
import { CreditCard, Smartphone, ShieldCheck, Zap } from 'lucide-react'

const WalletDashboard = ({ balance, setBalance }) => {
  const [amount, setAmount] = useState('')
  const [method, setMethod] = useState('card')
  const [loading, setLoading] = useState(false)

  const handleDeposit = (e) => {
    e.preventDefault()
    if(!amount || isNaN(amount)) return;
    
    setLoading(true)
    setTimeout(() => {
      setBalance(b => b + parseFloat(amount))
      setAmount('')
      setLoading(false)
    }, 1500)
  }

  return (
    <div className="mt-6 max-w-4xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Balance Card */}
        <div className="manga-glass rounded-elite border border-[#2a2a2c] p-8 flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 w-48 h-48 bg-elite-gold/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3"></div>
          
          <div>
            <h3 className="text-xs font-bold tracking-widest uppercase text-gray-400 mb-2">Available Capital</h3>
            <div className="text-5xl font-mono tracking-tight text-white font-light">
              ${balance.toLocaleString('en-US', {minimumFractionDigits: 2})}
            </div>
          </div>
          
          <div className="mt-12 pt-6 border-t border-[#2a2a2c] flex items-center justify-between text-sm text-gray-400">
            <span className="flex items-center gap-2"><ShieldCheck size={16} className="text-elite-gold" /> End-to-End Encrypted</span>
            <span className="uppercase tracking-widest text-[10px]">Algo.Secure™</span>
          </div>
        </div>

        {/* Recharge Form */}
        <div className="manga-glass rounded-elite border border-[#2a2a2c] p-8">
          <h3 className="text-sm font-bold tracking-widest uppercase mb-6">Inject Capital</h3>
          
          <div className="flex gap-4 mb-6">
            <button 
              onClick={() => setMethod('card')}
              className={`flex-1 py-3 px-4 rounded border flex flex-col items-center gap-2 transition-all duration-300 ${method === 'card' ? 'bg-elite-gray border-elite-gold text-elite-gold shadow-gold-glow' : 'bg-[#111112] border-[#333] text-gray-400 hover:border-[#555]'}`}
            >
              <CreditCard size={20} />
              <span className="text-xs uppercase tracking-widest font-semibold">Black Card</span>
            </button>
            <button 
              onClick={() => setMethod('upi')}
              className={`flex-1 py-3 px-4 rounded border flex flex-col items-center gap-2 transition-all duration-300 ${method === 'upi' ? 'bg-elite-gray border-elite-violet text-elite-violet shadow-violet-glow' : 'bg-[#111112] border-[#333] text-gray-400 hover:border-[#555]'}`}
            >
              <Smartphone size={20} />
              <span className="text-xs uppercase tracking-widest font-semibold">Crypto / UPI</span>
            </button>
          </div>

          <form onSubmit={handleDeposit} className="space-y-4">
            <div>
              <label className="block text-[10px] text-gray-500 uppercase tracking-widest mb-2">Amount (USD)</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-mono">$</span>
                <input 
                  type="number" 
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="elite-input pl-8 font-mono text-lg"
                  placeholder="0.00"
                  step="100"
                  min="0"
                  required
                />
              </div>
            </div>
            
            <button 
              type="submit" 
              disabled={loading}
              className="w-full elite-button bg-elite-gold text-black hover:bg-white flex items-center justify-center gap-2 mt-2 h-12"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>Authorize Transfer <Zap size={16} /></>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}

export default WalletDashboard
