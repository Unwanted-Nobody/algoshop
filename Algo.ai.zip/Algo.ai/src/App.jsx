import { useState } from 'react'
import Sidebar from './components/Sidebar'
import Navbar from './components/Navbar'
import HeroSection from './components/HeroSection'
import ProductGrid from './components/ProductGrid'
import PortfolioPanel from './components/PortfolioPanel'
import HistoryDashboard from './components/HistoryDashboard'
import WalletDashboard from './components/WalletDashboard'

function App() {
  const [currentView, setCurrentView] = useState('dashboard')
  const [walletBalance, setWalletBalance] = useState(15420.00)
  const [searchHistory, setSearchHistory] = useState([])
  
  const userRank = "Silver Member"
  const userName = "Takumi Fujiwara"

  const renderView = () => {
    switch(currentView) {
      case 'dashboard':
        return (
          <>
            <HeroSection />
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mt-6">
              <div className="xl:col-span-2">
                <ProductGrid title="Featured Elite Drops" limit={4} />
              </div>
              <div>
                <PortfolioPanel balance={walletBalance} />
              </div>
            </div>
          </>
        )
      case 'shop':
        return <ProductGrid title="The Elite Collection" />
      case 'portfolio':
        return <PortfolioPanel balance={walletBalance} expanded={true} />
      case 'history':
        return <HistoryDashboard />
      case 'wallet':
        return <WalletDashboard balance={walletBalance} setBalance={setWalletBalance} />
      default:
        return <HeroSection />
    }
  }

  return (
    <div className="flex h-screen overflow-hidden bg-elite-black selection:bg-elite-gold selection:text-black transition-colors duration-300">
      <Sidebar 
        currentView={currentView} 
        setCurrentView={setCurrentView} 
        userName={userName}
        userRank={userRank}
      />
      
      <main className="flex-1 flex flex-col h-screen overflow-hidden relative">
        <Navbar 
          balance={walletBalance} 
          userName={userName}
        />
        
        <div className="flex-1 overflow-y-auto p-4 md:p-8 scroll-smooth pb-20">
          <div className="max-w-7xl mx-auto animate-fade-in">
            {renderView()}
          </div>
        </div>
      </main>
    </div>
  )
}

export default App
