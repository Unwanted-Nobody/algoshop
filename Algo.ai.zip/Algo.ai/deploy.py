import urllib.request
import json
import ssl

with open('standalone.html', 'r', encoding='utf-8') as f:
    html_content = f.read()

payload = {
    "files": {
        "index.html": {
            "content": html_content
        },
        "package.json": {
            "content": {
                "name": "algo-shop-elite-edition",
                "version": "1.0.0",
                "description": "Hosted standalone React Preview",
                "main": "index.html",
                "scripts": {
                    "start": "serve ."
                },
                "dependencies": {
                    "serve": "^14.0.0"
                }
            }
        }
    }
}

data = json.dumps(payload).encode('utf-8')
url = "https://codesandbox.io/api/v1/sandboxes/define?json=1"
req = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json', 'Accept': 'application/json'})

try:
    context = ssl._create_unverified_context()
    with urllib.request.urlopen(req, context=context) as response:
        res_data = response.read()
        res_json = json.loads(res_data)
        sandbox_id = res_json.get("sandbox_id")
        if sandbox_id:
            print("SUCCESS")
            print(f"Editor Link: https://codesandbox.io/s/{sandbox_id}")
            print(f"App Link: https://{sandbox_id}.csb.app/")
        else:
            print("FAILED")
            print(res_json)
except Exception as e:
    print("ERROR:", str(e))
