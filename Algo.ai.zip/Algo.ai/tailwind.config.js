/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'elite-black': '#0b0b0c',
        'elite-gold': '#d4af37',
        'elite-violet': '#5d3fd3',
        'elite-text': '#f5f5f5',
        'elite-gray': '#1a1a1c',
        'elite-border': '#2a2a2c'
      },
      borderRadius: {
        'elite': '6px',
      },
      boxShadow: {
        'gold-glow': '0 0 15px rgba(212, 175, 55, 0.3)',
        'gold-glow-hover': '0 0 25px rgba(212, 175, 55, 0.5)',
        'violet-glow': '0 0 15px rgba(93, 63, 211, 0.3)',
        'violet-glow-hover': '0 0 25px rgba(93, 63, 211, 0.5)',
      },
      animation: {
        'spin-slow': 'spin 3s linear infinite',
      }
    },
  },
  plugins: [],
}
